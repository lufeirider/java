package member;


import member.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Widget {
	
	
	public String getInfo(String id)
	{
	    // 1 ����һ��sessionFactory����
	    Configuration configuration = new Configuration().configure();

	    SessionFactory sessionFactory = configuration.buildSessionFactory();

	    // 2 ����һ��session����
	    Session session = sessionFactory.openSession();
	    // 3 ��������
	    Transaction transaction = session.beginTransaction();

	    // 4 ִ�б���Ĳ���
//	    User user = new User();
//	    user.setUsername("lufei");
//	    user.setPassword("22222222");
//	    session.save(user);
	    
//	    User user1 = (User)session.get(User.class, 1);
//	    System.out.println(user1);
	    
	    //Query query = session.createQuery("select username from User where ID = " + id);
	    //Query query = session.createQuery("from User where ID = " + id);
	    Query query = session.createQuery("from User where ID =?0");
	    query.setParameter(0, id);
	    String result = query.list().toString();
	    
	    // 5 �ύ����
	    transaction.commit();
	    // 6 �ر�session
	    session.close();
	    sessionFactory.close();
		return result;
	}

}
